// yarn add socket-io express

const express = require('express');
const app = express();
const server = require('http').Server(app);
const io = require('socket.io')(server);
const path = require('path');
//记录登录的用户
var users=[];
const _socket=[]

//启动了服务器
server.listen(3000,'0.0.0.0', () => {
    console.log('服务器启动成功了')
});
app.use(express.static(path.join(__dirname,'./public')));
app.get('/', function (req, res) {
    res.sendFile(__dirname + '/index.html');
});

io.on('connection', (socket)=>{
    console.log('新用户连接了! '+socket.id);
    socket.on('login', data => {
        // console.log(data)
//判断,如果data在users中存在,说明该用户已经登录了,告诉不允许登录
//如果data在users中部存在,说明该用户没有登录,允许用户登录
        let user = users.find(item => item.username == data.username)
        if (user) {
            //用户存在,登录失败,服务器给用户相应,告诉登录失败
            socket.emit('loginError', {msg: '登录失败'})
            // console.log('登录失败')
        } else {
            //用户不存在,登录成功
            socket.username = data.username
            data={username:data.username,avatar:data.avatar,socketid:socket.id}
            users.push(data)
            _socket[data.username] = socket;
            //告诉用户,登录成功
            socket.emit('loginSuccess', data)
            // console.log(data.username+'登录成功')
            //告诉所有用户有人进来了,广播消息
            //socket.emit : 告诉当前用户
            //io.emit : 广播事件
            io.emit('addUser', data)
            //告诉所有用户,目前聊天室有多少人
            io.emit('userList', users)
            //把登录成功的用户名和头像存储起来
            
            socket.avatar = data.avatar
        }

    })

    //用户断开连接的功能
    //监听用户断开链接
    socket.on('disconnect', () => {
        //把当前用户从users中删除掉
        console.log('connection is disconnect!');
        console.log(socket.id);
        let idx = users.findIndex(item => item.username === socket.username)
        //删除掉断开链接的这个人
        users.splice(idx, 1)

        //1.告诉所有人,有人离开了聊天室
        io.emit('delUser', {
            username: socket.username,
            avatar: socket.avatar
        })
        //2.告诉所有人,userList 发生更新
        io.emit('userList', users)
    })

    //监听聊天的消息
    socket.on('sendMessage',data=>{
        //console.log(data)
        //广播给所有用户
        io.emit('receiveMessage',data)
    })

    //接受图片信息
    socket.on('sendImage',data=>{
        //console.log(data)
        //广播给所有用户
        io.emit('receiveImage',data)
    })
    socket.on('sendPrivateMessage',(data)=>{
        console.log(data)
        let toname = users.find(item => item.username == data.receipt)
        let fromname = users.find(item => item.username == data.address)
        if(toname){
            data={from:fromname,to:toname,msg:data.msg}
            _socket[toname.username].emit('message',data);
        }
      })
});

