##使用Socketio实现网页版qq
起因是老师布置的实验，模仿qq写一个即时通讯程序，我本人也比较感兴趣，觉得这个实现了应该蛮好玩，于是就在网上搜索一些相关的教程，找到了一个使用node.js编写的能实现群聊的网页程序，正好这学期学了一些node.js，感觉上手不难，就看完了视频教程，把群聊改成了私聊。由于本人比较菜，登录比较草率，也没用数据库，将聊天的信息直接存在数组里了。
课程链接放这里，有兴趣可以去看下。https://ke.qq.com/course/355307?taid=2788043660815339

####效果预览
这个是登录界面,UI是用的上面那个课程里的

![avatar](http://m.qpic.cn/psc?/V14Zppqj4enhoM/I4OEOPrz6D2aFnaB6dwLRVs8bez1CG5HsTw44*LcBHg4Te6pmJFy8S9pAvmeEinsHKGgNk.Vxsob0dvXjANX9KefV.A5Y7hv.QteEPtRHqA!/b&bo=2AMDBAAAAAARF*w!&rf=viewer_4)

登陆后的聊天界面，左边是已经登陆的用户列表，如果关闭网页，就会自动退出，列表上这个用户也会消失。

![avatar](http://m.qpic.cn/psc?/V14Zppqj4enhoM/I4OEOPrz6D2aFnaB6dwLRc9I4MdfJF*d15YVDxyfUMAnUnYWTNqburTX7kDiNmbiceDSswlvBQApungumYnm.QoWDR1WgEoepMUu5YNKxug!/b&bo=2AMDBAAAAAADF.4!&rf=viewer_4)

消息提醒。如果你没有选中某个用户跟他聊天，但又恰好他给你发了消息，这个时候就会在他的用户名后面产生带数字的小红点，里面的数字是他发送的消息数。（说这么一大串其实就是消息提醒啦）

![avatar](http://m.qpic.cn/psc?/V14Zppqj4enhoM/I4OEOPrz6D2aFnaB6dwLRRfEWXIN0lvpY727QVcJquzLwyXsSjKPtH*h9kB*bnL8qHA5OQmNIb1TZFBcFge09y.Xq.b3YetYghep4xwcGuw!/b&bo=2AMDBAAAAAADF.4!&rf=viewer_4)

正式的聊天界面。

![avatar](https://img-blog.csdnimg.cn/20200706223047632.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3dlaXhpbl80NDIwNDUxMQ==,size_16,color_FFFFFF,t_70#pic_center)

####私聊部分代码
首先是socektio。
app.js
``` javascript
const express = require('express');//引入express
const app = express();
const server = require('http').Server(app);
const io = require('socket.io')(server);//引入socket.io，将socket.io注入express模块
const path = require('path');

server.listen(3000,'0.0.0.0', () => {
    console.log('服务器启动成功了')
});//启动服务器，监听3000端口
``` 

更详细的也可以到官网进一步学习。
https://www.socket.io

事件的注册和处理
使用emit来注册事件，on来处理事件。
io.emit是广播，socket.emit是告诉当前用户，通过socket.id可以标识不同用户，以此来选择私聊时消息发送的对象。
用户登入，退出，用户列表的更新等，课程里都有详细介绍，我在这里就不赘述了，主要写写私聊功能的实现。
首先默认用户需点击他想私聊的对象，然后才可发送消息。所以先监听用户是否有点击某个用户的动作。
在更新用户列表时，每个li上添加一个getprivate事件。
```javascript
socket.on('userList',data=>{
    $('.user-list ul').html('')
    //把用户列表数据动态渲染到左侧菜单
    data.forEach(item=>{
        $('.user-list ul').append(`
        <li class="user" onclick="getprivate(this)">
            <div class="avatar"><img src="${item.avatar}" alt="" /></div>
            <div class="name">${item.username}</div>
            <div id="news"><span id="msgnum"></span></div>
          </li>
        `)
    })
})
```

index.html
``` javascript
function getprivate(v){
        var curname=$(v).children('.name').text()//获取当前私聊对象名
        var curavatar=$(v).find('img').attr('src')//获取当前私聊对象的头像
        $(v).children('#news').hide()//因为已经点击了用户了，如果对方之前发了消息的话，把消息提醒隐藏
        $(v).children('#msgnum').hide()//隐藏消息数
        weidumsgnum[curname]=0//将消息数置为0
        if(curname!=username){//确保不会点到自己
        $('.box-bd').html('')//清空聊天区
        $('#userName').text(curname)//聊天区上方变成选择聊天的对象名
        $('.btn-send-private').fadeIn()//显示发送按钮
        if(massage.length>0){//看看存储消息的数组中有没有值
        for (num=0;num<massage.length;num++){//因为每个网页都有一个唯一的socket.id，所以，每个网页的存储消息数组里只会有自己发送的和别人发给自己的消息，可以直接通过发送消息的人和接收消息的人来过滤应当显示的消息。
          if (username === massage[num].from && curname==massage[num].to) {//自己的消息就放在右边
        $('.box-bd').append(`
        <div class="message-box">
            <div class="my message">
              <img class="avatar" src="${avatar}" alt="" />
              <div class="content">
                <div class="bubble">
                  <div class="bubble_cont">${massage[num].msg}</div>
                </div>
              </div>
            </div>
          </div>
        `)
    } else if(curname===massage[num].from){//别人的消息放在左边
      console.log("click2")
        $('.box-bd').append(`
        <div class="message-box">
            <div class="other message">
              <img class="avatar" src="${curavatar}" alt="" />
              <div class="content">
                <div class="nickname">${curname}</div>
                <div class="bubble">
                  <div class="bubble_cont">${massage[num].msg}</div>
                </div>
              </div>
            </div>
          </div>
        `)
    }
    }
    // scrollIntoView()      
    }
    $('#btn-send-private').on('click',function(){
          //获取到聊天内容
          var nowtalkname=$('#userName').text()//获取到当前聊天的对象
              var content=$('#content').html()//获取聊天内容        
              if (!content){ 
                console.log(content)
                return alert('请输入内容')}
              $('#content.text').html('')
              //发送给app.js处理私发消息
              socket.emit('sendPrivateMessage',{
                  msg:content,
                  address:username,
                  receipt:nowtalkname,
              })//消息，发送者的名字和接受者的名字
              msgcon={from:username,to:nowtalkname,msg:content}
              massage.push(msgcon)//存进数组中
              $('.box-bd').append(`
        <div class="message-box">
            <div class="my message">
              <img class="avatar" src="${avatar}" alt="" />
              <div class="content">
                <div class="bubble">
                  <div class="bubble_cont">${content}</div>
                </div>
              </div>
            </div>
          </div>
        `)//显示在网页上
          })
        }else{
          return alert('不能与自己聊天！')
        }
      }
``` 
app.js
在用户登录时将用户的socket存进数组，通过用户名调用。
```javascript
_socket[data.username] = socket;
```
处理私聊事件
```javascript
    socket.on('sendPrivateMessage',(data)=>{
        let toname = users.find(item => item.username == data.receipt)//通过传来的数据中的接受者的用户名，找到之前存储在列表中的用户的完整信息
        let fromname = users.find(item => item.username == data.address)//通过传来的数据中的发送者的用户名，找到之前存储在列表中的用户的完整信息
        if(toname){
            data={from:fromname,to:toname,msg:data.msg}//更新下发送的数据
            _socket[toname.username].emit('message',data);//通过接受者的用户名取到socket,向那个用户的socekt发送消息
        }
      })
});
```
接收私聊消息
index.html
```javascript
socket.on('message',data=>{
        var nowtalkname=$('#userName').text()//获取到当前聊天的对象
        msgcon={from:data.from.username,to:data.to.username,msg:data.msg}
        massage.push(msgcon)//将收到的消息存进数组中
        if(nowtalkname!=data.from.username){//如果收到的不是当前用户发送的消息，就会有消息提醒，接下来都是消息提醒产生的逻辑
        //先建立一个数组，用每一个发送者的名字作下标，每一个第一次有消息提醒的用户名先以他的用户名为下标，值为1，然后再收到消息就寻找数组中有没有这个用户名为下标的元素，若有则继续加一，若无则创建一个
          if(weidumsgnum[data.from.username]){
            weidumsgnum[data.from.username]+=1
          }
          else{
            weidumsgnum[data.from.username]=1
          }
          var Uarray=$("#userlist").children("li")//获取到用户列表
          for(var i=0;i<Uarray.length;i++){
            var single=Uarray.eq(i)//遍历每一个用户，若名字与接收到的消息的发送者一样，就会将这个用户的消息提醒显示出来，并更新未读消息的数目
            let name=single.find(".name").html()
            console.log(name)
            if(name==data.from.username){
              single.find("#news").show()
              single.find('#msgnum').show()
              single.find('#msgnum').text(weidumsgnum[data.from.username])
            }
          }       
        }else{//如果发送消息的就是当前聊天的对象，那就直接显示在屏幕上
        $('.box-bd').append(`
        <div class="message-box">
            <div class="other message">
              <img class="avatar" src="${data.from.avatar}" alt="" />
              <div class="content">
                <div class="nickname">${data.from.username}</div>
                <div class="bubble">
                  <div class="bubble_cont">${data.msg}</div>
                </div>
              </div>
            </div>
          </div>
        `)
  scrollIntoView()
}
     });
```
####总结
一直在说学习编程，实践最重要，感觉也确实是。一直以来，我都只是死啃着书，学习理论，有点“怕”写代码，以至于现在感觉自己写不出啥，一敲键盘就脑袋空空。这个东西也不太成熟，可能有些地方我也只是会个皮毛，有些地方写的不太好，多多包涵。希望自己以后能多多练习吧，熟能生巧，继续努力吧！